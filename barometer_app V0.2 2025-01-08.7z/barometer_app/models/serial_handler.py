"""
Handles serial port communication for the barometer application.

Encapsulates logic for opening, closing, configuring, and communicating
over the serial port using the `pyserial` library.
"""

import serial

class SerialHandler:
    """
    Handles serial communication logic.
    """

    def __init__(self):
        """
        Initializes the SerialHandler with a default port as None.
        """
        self.port = None

    def configure(self, port, baudrate, parity, stopbits, bytesize):
        """
        Configures the serial port with the specified parameters.

        Args:
            port (str): Serial port name (e.g., 'COM3' or '/dev/ttyUSB0').
            baudrate (int): Baud rate (e.g., 9600).
            parity (str): Parity (e.g., 'N' for None).
            stopbits (int): Number of stop bits (e.g., 1 or 2).
            bytesize (int): Byte size (e.g., 8).
        """
        self.port = serial.Serial(
            port=port,
            baudrate=baudrate,
            parity=parity,
            stopbits=stopbits,
            bytesize=bytesize,
            timeout=1  # Timeout for read/write operations
        )

    def open_connection(self):
        """
        Opens the serial connection if it is not already open.
        """
        if self.port and not self.port.is_open:
            self.port.open()

    def close_connection(self):
        """
        Closes the serial connection if it is currently open.
        """
        if self.port and self.port.is_open:
            self.port.close()

    def send(self, command):
        """
        Sends a command over the serial connection.

        Args:
            command (str): The command to send as a string.
        """
        if self.port and self.port.is_open:
            self.port.write(command.encode('utf-8'))

    def receive(self):
        """
        Reads a response from the serial connection.

        Returns:
            str: The received response as a string.
        """
        if self.port and self.port.is_open:
            return self.port.read_until().decode('utf-8')
       
    def receive_until(self, terminator):
        """
        Reads data from the serial port until a specific terminator is found.

        Args:
            terminator (str): The character indicating the end of the response.

        Returns:
            str: The full response read from the serial port.
        """
        if self.port and self.port.is_open:
            response = ""
            while True:
                chunk = self.port.read_until().decode('utf-8')
                response += chunk
                if terminator in response:
                    break
            return response
        return ""
